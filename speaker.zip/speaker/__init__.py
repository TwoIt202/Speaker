"""
:authors: two-it2022
:license: Apache License, Version 0.1, see LICENSE file

:copyright: (c) 2022 two-it2022
"""


__author__ = 'two-it2022'
__version__ = '0.0.1'
__email__ = 'kodland.group@gmail.com'
