# SPEAKER

# Imports
import pyttsx3
import speech_recognition







engine = pyttsx3.init()
sr = speech_recognition.Recognizer()

def speak(text, gender, speed):
      rate = engine.getProperty('rate')
      engine.setProperty('rate', speed)

      voices = engine.getProperty('voices')

      if gender == "male":
            engine.setProperty('voice', voices[0].id)
      elif gender == "female":
            engine.setProperty('voice', voices[1].id)
      elif gender != "male" or gender != "female":
            engine.setProperty('voice', voices[0].id)
      elif gender == None:
            engine.setProperty('voice', voices[0].id)
      else:
            engine.setProperty('voice', voices[0].id)

      engine.say(text)
      engine.runAndWait()




def listen(pausetime, language):

      # Varibles
      global query
      sr.pause_threshold = pausetime

      print("Microphone is started!")
      
      with speech_recognition.Microphone() as mic:

            # Varibles
            sr.adjust_for_ambient_noise(source=mic, duration=pausetime)
            audio = sr.listen(source=mic)
            query = sr.recognize_google(audio_data=audio, language=language)

      return query